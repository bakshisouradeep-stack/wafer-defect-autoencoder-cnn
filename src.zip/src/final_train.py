"""
Final training run: loads the best hyperparameters found by hpo.py and
trains for substantially more epochs, with early-stopping-style best
checkpoint selection on validation accuracy.
"""
import json
import sys
import torch

sys.path.insert(0, "/home/deep/Wafetr_defect/project/src")
from train_classifier import train_one_config
from common import get_device, configure_cpu_threads

HPO_RESULTS = "/home/deep/Wafetr_defect/project/data/hpo_results.json"
FINAL_CKPT = "/home/deep/Wafetr_defect/project/data/classifier_final.pt"
FINAL_EPOCHS = 60


def main():
    configure_cpu_threads()
    print("Device:", get_device(), flush=True)
    with open(HPO_RESULTS) as f:
        hpo = json.load(f)
    params = hpo["best_params"]
    print("Using best HPO params:", params, flush=True)

    result = train_one_config(
        base_filters=params["base_filters"],
        dropout=params["dropout"],
        lr=params["lr"],
        weight_decay=params["weight_decay"],
        batch_size=params["batch_size"],
        epochs=FINAL_EPOCHS,
        use_pretrained_encoder=True,
        verbose=True,
    )

    print("\n=== Final training complete ===", flush=True)
    print("Best val acc:", result["best_val_acc"], flush=True)
    print("Best val prec (macro):", result["best_val_prec"], flush=True)

    torch.save({"state": result["best_state"], "config": result["config"]}, FINAL_CKPT)
    with open("/home/deep/Wafetr_defect/project/data/final_train_history.json", "w") as f:
        json.dump(result["history"], f, indent=2)
    print("Saved final checkpoint to", FINAL_CKPT, flush=True)


if __name__ == "__main__":
    main()
