"""Shared utilities: device selection and OOM-safe training-step wrapper."""
import os
import time
import torch

CPU_CORE_CAP = 28  # flat cap, always -- be considerate of other users on
                    # this shared 128-core box, whether we're on CPU or GPU


def configure_cpu_threads(device=None, n=None):
    """Always cap CPU threads (and data-loading workers) to CPU_CORE_CAP,
    regardless of whether training runs on CPU or CUDA."""
    if n is None:
        n = CPU_CORE_CAP
    os.environ["OMP_NUM_THREADS"] = str(n)
    os.environ["MKL_NUM_THREADS"] = str(n)
    torch.set_num_threads(n)
    return n


def get_device():
    return "cuda" if torch.cuda.is_available() else "cpu"


def run_step_with_oom_retry(step_fn, max_retries=240, wait_seconds=15):
    """Run step_fn() (a closure that does one forward+backward+optimizer
    step) and, if CUDA runs out of memory because another user on this
    shared GPU grabbed it, back off and retry instead of crashing the
    whole multi-hour job."""
    for attempt in range(max_retries):
        try:
            return step_fn()
        except torch.cuda.OutOfMemoryError:
            torch.cuda.empty_cache()
            print(f"  [transient CUDA OOM, other user's job likely spiked "
                  f"memory -- retry {attempt + 1}/{max_retries} in "
                  f"{wait_seconds}s]", flush=True)  # flush: avoid buffered-output confusion
            time.sleep(wait_seconds)
    raise RuntimeError("Exceeded max OOM retries; GPU appears persistently unavailable.")
