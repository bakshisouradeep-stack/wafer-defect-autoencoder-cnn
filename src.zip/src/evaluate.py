"""
Final held-out TEST SET evaluation (never touched during training/HPO):
overall accuracy, macro/weighted precision-recall-F1, per-class report,
and confusion matrix figure.
"""
import json
import sys
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, confusion_matrix, classification_report,
                              balanced_accuracy_score)

sys.path.insert(0, "/home/deep/Wafetr_defect/project/src")
from model import Encoder, WaferCNNClassifier
from train_classifier import load_data, make_loader, evaluate_loader
from common import get_device, configure_cpu_threads

DATA_DIR = "/home/deep/Wafetr_defect/project/data"
FINAL_CKPT = f"{DATA_DIR}/classifier_final.pt"
RESULTS_DIR = "/home/deep/Wafetr_defect/project/results"
CLASSES = open(f"{DATA_DIR}/classes.txt").read().splitlines()


def main():
    configure_cpu_threads()
    device = get_device()
    print("Device:", device, flush=True)

    ckpt = torch.load(FINAL_CKPT, map_location="cpu", weights_only=False)
    cfg = ckpt["config"]
    print("Loaded config:", cfg, flush=True)

    encoder = Encoder(base_filters=cfg["base_filters"])
    model = WaferCNNClassifier(num_classes=9, base_filters=cfg["base_filters"],
                                dropout=cfg["dropout"], encoder=encoder).to(device)
    model.load_state_dict(ckpt["state"])
    model.eval()

    (_, _), (_, _), (Xte, yte) = load_data()
    test_loader = make_loader(Xte, yte, batch_size=cfg["batch_size"], shuffle=False)

    acc, prec_macro, preds, labels = evaluate_loader(model, test_loader)
    prec_weighted = precision_score(labels, preds, average="weighted", zero_division=0)
    rec_macro = recall_score(labels, preds, average="macro", zero_division=0)
    f1_macro = f1_score(labels, preds, average="macro", zero_division=0)
    bal_acc = balanced_accuracy_score(labels, preds)

    report = classification_report(labels, preds, target_names=CLASSES,
                                    zero_division=0, digits=4)
    print("\n=== TEST SET RESULTS (held out, never seen in training/HPO) ===")
    print(f"Accuracy:            {acc:.4f}")
    print(f"Balanced accuracy:   {bal_acc:.4f}")
    print(f"Precision (macro):   {prec_macro:.4f}")
    print(f"Precision (weighted):{prec_weighted:.4f}")
    print(f"Recall (macro):      {rec_macro:.4f}")
    print(f"F1 (macro):          {f1_macro:.4f}")
    print("\nPer-class report:\n", report)

    cm = confusion_matrix(labels, preds)
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)

    fig, ax = plt.subplots(figsize=(8, 7))
    im = ax.imshow(cm_norm, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(len(CLASSES)))
    ax.set_yticks(range(len(CLASSES)))
    ax.set_xticklabels(CLASSES, rotation=45, ha="right")
    ax.set_yticklabels(CLASSES)
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("True label")
    ax.set_title("Confusion Matrix (row-normalized)")
    for i in range(len(CLASSES)):
        for j in range(len(CLASSES)):
            val = cm_norm[i, j]
            ax.text(j, i, f"{val:.2f}", ha="center", va="center",
                    color="white" if val > 0.5 else "black", fontsize=8)
    fig.colorbar(im, ax=ax, label="fraction of true class")
    fig.tight_layout()
    fig.savefig(f"{RESULTS_DIR}/figures/confusion_matrix.png", dpi=200)
    print(f"\nSaved confusion matrix to {RESULTS_DIR}/figures/confusion_matrix.png")

    metrics = {
        "accuracy": acc, "balanced_accuracy": bal_acc,
        "precision_macro": prec_macro, "precision_weighted": prec_weighted,
        "recall_macro": rec_macro, "f1_macro": f1_macro,
        "classification_report": report,
        "confusion_matrix": cm.tolist(),
        "classes": CLASSES,
        "config": cfg,
    }
    with open(f"{RESULTS_DIR}/metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    print("Saved metrics to", f"{RESULTS_DIR}/metrics.json")


if __name__ == "__main__":
    main()
