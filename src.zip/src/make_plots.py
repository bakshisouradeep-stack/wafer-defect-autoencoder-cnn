"""Generates training-curve and HPO-summary figures from the saved
JSON histories, for inclusion in the project report."""
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DATA_DIR = "/home/deep/Wafetr_defect/project/data"
FIG_DIR = "/home/deep/Wafetr_defect/project/results/figures"


def plot_ae_history():
    with open(f"{DATA_DIR}/ae_history.json") as f:
        hist = json.load(f)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(range(1, len(hist) + 1), hist, marker="o", markersize=3)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Reconstruction MSE")
    ax.set_title("Autoencoder pretraining")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/ae_training_curve.png", dpi=200)
    print("saved ae_training_curve.png")


def plot_final_history():
    with open(f"{DATA_DIR}/final_train_history.json") as f:
        hist = json.load(f)
    epochs = [h["epoch"] for h in hist]
    train_loss = [h["train_loss"] for h in hist]
    val_acc = [h["val_acc"] for h in hist]
    val_prec = [h["val_prec_macro"] for h in hist]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(epochs, train_loss, color="tab:red")
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Training loss (cross-entropy)")
    axes[0].set_title("Final classifier: training loss")
    axes[0].grid(alpha=0.3)

    axes[1].plot(epochs, val_acc, label="Validation accuracy", color="tab:blue")
    axes[1].plot(epochs, val_prec, label="Validation precision (macro)", color="tab:green")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Score")
    axes[1].set_title("Final classifier: validation metrics")
    axes[1].legend()
    axes[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/final_training_curve.png", dpi=200)
    print("saved final_training_curve.png")


def plot_hpo_summary():
    with open(f"{DATA_DIR}/hpo_results.json") as f:
        hpo = json.load(f)
    trials = hpo["all_trials"]
    nums = [t["number"] for t in trials]
    vals = [t["value"] for t in trials]

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.scatter(nums, vals, color="tab:purple")
    best_idx = int(max(range(len(vals)), key=lambda i: vals[i]))
    ax.scatter([nums[best_idx]], [vals[best_idx]], color="tab:red", s=80,
               zorder=5, label="best trial")
    ax.set_xlabel("Trial number")
    ax.set_ylabel("Validation accuracy (proxy, few epochs)")
    ax.set_title("Bayesian hyperparameter search (Optuna / TPE)")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/hpo_trials.png", dpi=200)
    print("saved hpo_trials.png")


if __name__ == "__main__":
    plot_ae_history()
    plot_hpo_summary()
    plot_final_history()
