"""
Exploratory / architecture figures for the project report that do not
depend on the trained model: example wafer maps per class, class
distribution before/after balancing, and an architecture diagram.
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch, Rectangle

FIG_DIR = "/home/deep/Wafetr_defect/project/results/figures"
DATA_DIR = "/home/deep/Wafetr_defect/project/data"
PKL_PATH = "/home/deep/Wafetr_defect/LSWMD.pkl"

CLASSES = ["none", "Center", "Donut", "Edge-Loc", "Edge-Ring",
           "Loc", "Random", "Scratch", "Near-full"]

RAW_COUNTS = {  # from the full WM-811K labeled subset (see report Sec. 2)
    "none": 147431, "Edge-Ring": 9680, "Edge-Loc": 5189, "Center": 4294,
    "Loc": 3593, "Scratch": 1193, "Random": 866, "Donut": 555, "Near-full": 149,
}


def fig_example_wafers():
    df = pd.read_pickle(PKL_PATH)

    def get_failure(x):
        if isinstance(x, np.ndarray) and x.size > 0:
            return x[0][0]
        return None

    df["label"] = df["failureType"].apply(get_failure)

    fig, axes = plt.subplots(3, 3, figsize=(9, 9))
    cmap = matplotlib.colors.ListedColormap(["white", "#4C72B0", "#C44E52"])
    for ax, cls in zip(axes.flat, CLASSES):
        sub = df[df["label"] == cls]
        wm = sub["waferMap"].iloc[0]
        ax.imshow(wm, cmap=cmap, vmin=0, vmax=2, interpolation="nearest")
        ax.set_title(f"{cls}  (n={RAW_COUNTS[cls]:,})", fontsize=11)
        ax.set_xticks([]); ax.set_yticks([])
    fig.suptitle("Representative wafer maps for each of the 9 classes\n"
                  "(white = outside wafer, blue = normal die, red = defective die)",
                  fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(f"{FIG_DIR}/example_wafers_per_class.png", dpi=200)
    print("saved example_wafers_per_class.png")


def fig_class_distribution():
    final_target = 6667  # balanced training target per class

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    # left: raw/original distribution (log scale, since 'none' dominates)
    order = sorted(CLASSES, key=lambda c: -RAW_COUNTS[c])
    vals = [RAW_COUNTS[c] for c in order]
    axes[0].bar(order, vals, color="#4C72B0")
    axes[0].set_yscale("log")
    axes[0].set_ylabel("Count (log scale)")
    axes[0].set_title("(a) Original labeled WM-811K subset\n(172,950 wafers, 9 classes)")
    axes[0].tick_params(axis="x", rotation=45)
    for i, v in enumerate(vals):
        axes[0].text(i, v * 1.15, f"{v:,}", ha="center", fontsize=8, rotation=90)

    # right: curated balanced training set
    vals2 = [final_target for _ in order]
    axes[1].bar(order, vals2, color="#55A868")
    axes[1].set_ylabel("Count")
    axes[1].set_title("(b) Curated 60K training set\n(balanced: 6,667 per class)")
    axes[1].tick_params(axis="x", rotation=45)
    axes[1].set_ylim(0, final_target * 1.25)
    for i, v in enumerate(vals2):
        axes[1].text(i, v + 200, f"{v:,}", ha="center", fontsize=8)

    fig.suptitle("Class imbalance before and after rebalancing "
                  "(train split only; val/test stay real & imbalanced)", fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    fig.savefig(f"{FIG_DIR}/class_distribution_before_after.png", dpi=200)
    print("saved class_distribution_before_after.png")


def fig_architecture():
    fig, ax = plt.subplots(figsize=(15, 6))
    ax.set_xlim(0, 15.2)
    ax.set_ylim(0, 6)
    ax.axis("off")

    def box(x, y, w, h, text, color="#DDEBF7", fontsize=9):
        rect = Rectangle((x, y), w, h, facecolor=color, edgecolor="black", linewidth=1.2)
        ax.add_patch(rect)
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fontsize,
                wrap=True)
        return (x, y, w, h)

    def arrow(x1, y1, x2, y2):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                      mutation_scale=14, linewidth=1.2, color="black"))

    # Stage 1: autoencoder pretraining (top row)
    ax.text(0.1, 5.7, "Stage 1 -- Unsupervised autoencoder pretraining (encoder + decoder)",
            fontsize=11, fontweight="bold")
    x = 0.3
    labels = ["Input\n1x128x128", "Conv-BN-ReLU\nx2, 128->64", "Conv-BN-ReLU\nx2, 64->32",
              "Conv-BN-ReLU\nx2, 32->16", "Conv-BN-ReLU\nx2, 16->8\n(latent)"]
    boxes = []
    for lab in labels:
        b = box(x, 4.3, 1.9, 1.1, lab, color="#DDEBF7")
        boxes.append(b)
        x += 2.1
    for i in range(len(boxes) - 1):
        arrow(boxes[i][0] + boxes[i][2], 4.85, boxes[i + 1][0], 4.85)
    dec_labels = ["Deconv x4\n8->16->32->64->128", "Reconstruction\n1x128x128"]
    x2 = x
    for lab in dec_labels:
        b = box(x2, 4.3, 1.9, 1.1, lab, color="#FCE4D6")
        boxes.append(b)
        x2 += 2.1
    arrow(boxes[4][0] + boxes[4][2], 4.85, boxes[5][0], 4.85)
    arrow(boxes[5][0] + boxes[5][2], 4.85, boxes[6][0], 4.85)

    # Stage 2: classifier (bottom row), reusing the trained encoder
    ax.text(0.1, 3.0, "Stage 2 -- Classifier: reuse pretrained encoder + head "
                      "(Bayesian-HPO-tuned filters/dropout/lr)", fontsize=11, fontweight="bold")
    x = 0.3
    clf_labels = ["Input\n1x128x128", "Pretrained\nEncoder\n(4 conv-BN-ReLU\nstages)",
                  "Spatial2D\nDropout", "Global Avg\nPool", "Dense+BN+ReLU\n+ Dropout",
                  "Softmax\n9 classes"]
    cboxes = []
    for lab in clf_labels:
        b = box(x, 1.4, 1.75, 1.3, lab, color="#E2EFDA", fontsize=8.5)
        cboxes.append(b)
        x += 1.95
    for i in range(len(cboxes) - 1):
        arrow(cboxes[i][0] + cboxes[i][2], 2.05, cboxes[i + 1][0], 2.05)

    ax.annotate("", xy=(cboxes[1][0] + cboxes[1][2] / 2, 2.7),
                xytext=(boxes[4][0] + boxes[4][2] / 2, 4.3),
                arrowprops=dict(arrowstyle="-|>", linestyle="--", color="gray",
                                 linewidth=1.3))
    ax.text((cboxes[1][0] + boxes[4][0]) / 2 + 1, 3.55, "weights\ntransferred",
            fontsize=8, color="gray", ha="center")

    fig.tight_layout()
    fig.savefig(f"{FIG_DIR}/architecture_diagram.png", dpi=200)
    print("saved architecture_diagram.png")


if __name__ == "__main__":
    fig_example_wafers()
    fig_class_distribution()
    fig_architecture()
