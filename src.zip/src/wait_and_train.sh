#!/bin/bash
# Poll the shared GPU until enough memory is free (sustained across a few
# checks, to avoid jumping into a momentary gap and immediately OOMing),
# then run the full pipeline: autoencoder pretrain -> Bayesian HPO ->
# final classifier training -> test-set evaluation -> report figures.
set -uo pipefail

PY=/home/deep/miniconda3/envs/magnetic_ai/bin/python3
SRC=/home/deep/Wafetr_defect/project/src
LOG=/home/deep/Wafetr_defect/project/results/pipeline.log
THRESHOLD_MIB=1000
REQUIRED_CONSECUTIVE=2
POLL_SECONDS=15
MAX_WAIT_HOURS=48

mkdir -p "$(dirname "$LOG")"
: > "$LOG"

echo "[$(date)] Waiting for >= ${THRESHOLD_MIB} MiB free on GPU 0 "\
     "(sustained for ${REQUIRED_CONSECUTIVE} checks, ${POLL_SECONDS}s apart)..." | tee -a "$LOG"

consecutive=0
elapsed=0
max_elapsed=$((MAX_WAIT_HOURS * 3600))

while [ "$elapsed" -lt "$max_elapsed" ]; do
    free_mib=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits -i 0 2>/dev/null | head -1)
    if [ -z "$free_mib" ]; then
        echo "[$(date)] nvidia-smi query failed, retrying..." | tee -a "$LOG"
        consecutive=0
    elif [ "$free_mib" -ge "$THRESHOLD_MIB" ]; then
        consecutive=$((consecutive + 1))
        echo "[$(date)] free=${free_mib} MiB (>= threshold) -- ${consecutive}/${REQUIRED_CONSECUTIVE} consecutive checks" | tee -a "$LOG"
        if [ "$consecutive" -ge "$REQUIRED_CONSECUTIVE" ]; then
            echo "[$(date)] GPU confirmed free. Starting training pipeline." | tee -a "$LOG"
            break
        fi
    else
        if [ "$consecutive" -gt 0 ]; then
            echo "[$(date)] free=${free_mib} MiB (< threshold) -- reset counter" | tee -a "$LOG"
        fi
        consecutive=0
    fi
    sleep "$POLL_SECONDS"
    elapsed=$((elapsed + POLL_SECONDS))
done

if [ "$elapsed" -ge "$max_elapsed" ]; then
    echo "[$(date)] Gave up waiting for GPU after ${MAX_WAIT_HOURS}h." | tee -a "$LOG"
    exit 1
fi

run_stage () {
    name="$1"; shift
    echo "" | tee -a "$LOG"
    echo "=================================================================" | tee -a "$LOG"
    echo "[$(date)] STAGE: $name" | tee -a "$LOG"
    echo "=================================================================" | tee -a "$LOG"
    "$@" 2>&1 | tee -a "$LOG"
    rc=${PIPESTATUS[0]}
    if [ "$rc" -ne 0 ]; then
        echo "[$(date)] STAGE FAILED: $name (exit $rc)" | tee -a "$LOG"
        exit "$rc"
    fi
}

run_stage "1. Autoencoder pretraining"      "$PY" "$SRC/train_autoencoder.py"
run_stage "2. Bayesian hyperparameter search" "$PY" "$SRC/hpo.py"
run_stage "3. Final classifier training"     "$PY" "$SRC/final_train.py"
run_stage "4. Held-out test-set evaluation"  "$PY" "$SRC/evaluate.py"
run_stage "5. Generating report figures"     "$PY" "$SRC/make_plots.py"

echo "" | tee -a "$LOG"
echo "[$(date)] PIPELINE COMPLETE. See $LOG and project/results/metrics.json" | tee -a "$LOG"
