"""
Unsupervised pretraining of the convolutional autoencoder backbone on the
balanced 60K training-split wafer maps (labels are not used at this stage,
so the real/augmented provenance of an image is irrelevant here; no
evaluation leakage is introduced since val/test are never touched). The
trained encoder weights are saved and later reused to initialize the
classifier.
"""
import json
import time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

import sys
sys.path.insert(0, "/home/deep/Wafetr_defect/project/src")
from model import ConvAutoencoder
from common import get_device, run_step_with_oom_retry, configure_cpu_threads

DATA_DIR = "/home/deep/Wafetr_defect/project/data"
CKPT_PATH = "/home/deep/Wafetr_defect/project/data/autoencoder.pt"
DEVICE = get_device()
N_CPU = configure_cpu_threads()

BATCH_SIZE = 32  # kept small -- GPU memory on this shared box is volatile
EPOCHS = 30
LR = 1e-3
BASE_FILTERS = 16  # smaller footprint for resilience; HPO still sweeps [16,32,48]


def main():
    print(f"Device: {DEVICE}  (CPU threads capped at {N_CPU})", flush=True)
    train = np.load(f"{DATA_DIR}/train.npz")
    X = torch.from_numpy(train["X"])
    ds = TensorDataset(X)
    dl = DataLoader(ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=2,
                     pin_memory=(DEVICE == "cuda"))

    model = ConvAutoencoder(base_filters=BASE_FILTERS).to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    crit = nn.MSELoss()

    history = []
    for epoch in range(1, EPOCHS + 1):
        t0 = time.time()
        model.train()
        total_loss = 0.0
        n = 0
        for (xb,) in dl:
            xb = xb.to(DEVICE, non_blocking=True)

            def step():
                opt.zero_grad()
                out = model(xb)
                loss = crit(out, xb)
                loss.backward()
                opt.step()
                return loss.item()

            loss_val = run_step_with_oom_retry(step) if DEVICE == "cuda" else step()
            total_loss += loss_val * xb.size(0)
            n += xb.size(0)
        avg_loss = total_loss / n
        history.append(avg_loss)
        print(f"Epoch {epoch:3d}/{EPOCHS}  recon_MSE={avg_loss:.6f}  "
              f"({time.time()-t0:.1f}s)", flush=True)

    torch.save({"encoder_state": model.encoder.state_dict(),
                "full_state": model.state_dict(),
                "base_filters": BASE_FILTERS}, CKPT_PATH)
    with open(f"{DATA_DIR}/ae_history.json", "w") as f:
        json.dump(history, f)
    print("Saved autoencoder checkpoint to", CKPT_PATH, flush=True)


if __name__ == "__main__":
    main()
