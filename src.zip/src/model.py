"""
Double-layer CNN + Convolutional Autoencoder for WM-811K wafer-map
defect classification. Reverse-engineered from the described architecture:
  - BatchNorm immediately before ReLU in every conv block
  - "Double-layer" conv blocks (two conv layers per spatial stage)
  - Spatial 2D Dropout (drops whole feature maps, not individual pixels)
  - Autoencoder pretraining of the convolutional backbone, whose encoder
    is then reused (and fine-tuned) as the classifier's feature extractor
"""
import torch
import torch.nn as nn


def conv_block(in_ch, out_ch, k=3):
    """One 'double-layer' conv block: two conv-BN-ReLU layers, matching the
    paper's description of BatchNorm immediately preceding ReLU."""
    return nn.Sequential(
        nn.Conv2d(in_ch, out_ch, k, padding=k // 2),
        nn.BatchNorm2d(out_ch),
        nn.ReLU(inplace=True),
        nn.Conv2d(out_ch, out_ch, k, padding=k // 2),
        nn.BatchNorm2d(out_ch),
        nn.ReLU(inplace=True),
    )


class Encoder(nn.Module):
    """4 downsampling stages: 128 -> 64 -> 32 -> 16 -> 8, channels f -> 8f."""

    def __init__(self, base_filters=32, in_ch=1):
        super().__init__()
        f = base_filters
        self.stage1 = conv_block(in_ch, f)       # 128 -> 128
        self.pool1 = nn.MaxPool2d(2)             # -> 64
        self.stage2 = conv_block(f, 2 * f)       # 64 -> 64
        self.pool2 = nn.MaxPool2d(2)             # -> 32
        self.stage3 = conv_block(2 * f, 4 * f)   # 32 -> 32
        self.pool3 = nn.MaxPool2d(2)             # -> 16
        self.stage4 = conv_block(4 * f, 8 * f)   # 16 -> 16
        self.pool4 = nn.MaxPool2d(2)             # -> 8
        self.out_channels = 8 * f

    def forward(self, x):
        x = self.pool1(self.stage1(x))
        x = self.pool2(self.stage2(x))
        x = self.pool3(self.stage3(x))
        x = self.pool4(self.stage4(x))
        return x  # (N, 8f, 8, 8)


class Decoder(nn.Module):
    """Mirrors the encoder with transposed-conv upsampling, for autoencoder
    pretraining of the shared backbone."""

    def __init__(self, base_filters=32, out_ch=1):
        super().__init__()
        f = base_filters

        def up(in_ch, out_ch):
            return nn.Sequential(
                nn.ConvTranspose2d(in_ch, out_ch, kernel_size=2, stride=2),
                nn.BatchNorm2d(out_ch),
                nn.ReLU(inplace=True),
            )

        self.up1 = up(8 * f, 4 * f)   # 8 -> 16
        self.dec1 = conv_block(4 * f, 4 * f)
        self.up2 = up(4 * f, 2 * f)   # 16 -> 32
        self.dec2 = conv_block(2 * f, 2 * f)
        self.up3 = up(2 * f, f)       # 32 -> 64
        self.dec3 = conv_block(f, f)
        self.up4 = up(f, f)           # 64 -> 128
        self.final = nn.Conv2d(f, out_ch, kernel_size=1)
        self.act = nn.Sigmoid()

    def forward(self, x):
        x = self.dec1(self.up1(x))
        x = self.dec2(self.up2(x))
        x = self.dec3(self.up3(x))
        x = self.up4(x)
        x = self.final(x)
        return self.act(x)


class ConvAutoencoder(nn.Module):
    def __init__(self, base_filters=32):
        super().__init__()
        self.encoder = Encoder(base_filters)
        self.decoder = Decoder(base_filters)

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z)


class WaferCNNClassifier(nn.Module):
    """Classifier head reusing an (optionally pretrained) Encoder backbone,
    followed by Spatial-2D-Dropout + global pooling + dense layers."""

    def __init__(self, num_classes=9, base_filters=32, dropout=0.3, encoder=None):
        super().__init__()
        self.encoder = encoder if encoder is not None else Encoder(base_filters)
        c = self.encoder.out_channels
        self.spatial_dropout = nn.Dropout2d(p=dropout)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.head = nn.Sequential(
            nn.Linear(c, c // 2),
            nn.BatchNorm1d(c // 2),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(c // 2, num_classes),
        )

    def forward(self, x):
        z = self.encoder(x)
        z = self.spatial_dropout(z)
        z = self.gap(z).flatten(1)
        return self.head(z)


if __name__ == "__main__":
    ae = ConvAutoencoder()
    x = torch.randn(2, 1, 128, 128)
    print("autoencoder out:", ae(x).shape)
    clf = WaferCNNClassifier(num_classes=9, encoder=ae.encoder)
    print("classifier out:", clf(x).shape)
    n_params = sum(p.numel() for p in clf.parameters())
    print("classifier params:", n_params)
