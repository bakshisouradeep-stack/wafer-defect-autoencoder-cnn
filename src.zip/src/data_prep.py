"""
Data preparation for the WM-811K wafer-map defect classification task.

Methodology (deliberately avoids train/test leakage):
  1. Load the raw LSWMD.pkl and keep only wafers with a labeled failureType.
  2. Map the 9 classes: none, Center, Donut, Edge-Loc, Edge-Ring, Loc,
     Random, Scratch, Near-full.
  3. Cap the overwhelming 'none' majority class to a manageable pool.
  4. For every class, split the REAL (unaugmented) samples into
     train/val/test BEFORE any augmentation is applied.
  5. Resize every wafer map (bilinear) to a fixed size.
  6. Only the TRAIN split is rebalanced to a per-class target count,
     via undersampling (classes with surplus) or augmentation
     (classes with a deficit: random rotation, flips, small translation,
     shear). Validation and test sets stay REAL and class-imbalanced,
     reflecting true-world defect rarity.

Output: compressed .npz files under project/data/
"""
import os
import time
import numpy as np
import pandas as pd
import cv2
from sklearn.model_selection import train_test_split

RNG = np.random.default_rng(42)

PKL_PATH = "/home/deep/Wafetr_defect/LSWMD.pkl"
OUT_DIR = "/home/deep/Wafetr_defect/project/data"
IMG_SIZE = 128
NONE_CAP = 20000          # cap the 'none' majority class before splitting
TRAIN_TARGET_PER_CLASS = 6667   # -> 9 * 6667 = 60003 training images
VAL_FRAC = 0.15
TEST_FRAC = 0.15

CLASSES = ["none", "Center", "Donut", "Edge-Loc", "Edge-Ring",
           "Loc", "Random", "Scratch", "Near-full"]
CLASS_TO_IDX = {c: i for i, c in enumerate(CLASSES)}


def load_labeled_dataframe():
    print("Loading LSWMD.pkl ...")
    t0 = time.time()
    df = pd.read_pickle(PKL_PATH)
    print(f"  loaded {len(df)} rows in {time.time()-t0:.1f}s")

    def get_failure(x):
        if isinstance(x, np.ndarray) and x.size > 0:
            return x[0][0]
        return None

    df["label"] = df["failureType"].apply(get_failure)
    labeled = df[df["label"].isin(CLASSES)].copy()
    labeled = labeled[["waferMap", "label"]].reset_index(drop=True)
    print(f"  labeled subset: {len(labeled)} rows")
    print(labeled["label"].value_counts())
    return labeled


def resize_map(wafer_map):
    """Bilinear-resize a categorical {0,1,2} wafer map to IMG_SIZE x IMG_SIZE,
    normalized to [0, 1]. Single channel (see report for rationale)."""
    arr = wafer_map.astype(np.float32)
    resized = cv2.resize(arr, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_LINEAR)
    resized = resized / 2.0  # raw values are {0,1,2} -> [0, 1]
    return resized.astype(np.float32)


def augment_one(img):
    """Apply one random augmentation: rotation in [-180,180], random flips,
    small translation, small shear. Operates on the already-resized image."""
    h, w = img.shape
    angle = RNG.uniform(-180, 180)
    tx = RNG.uniform(-0.08, 0.08) * w
    ty = RNG.uniform(-0.08, 0.08) * h
    shear = RNG.uniform(-0.15, 0.15)

    center = (w / 2.0, h / 2.0)
    rot_mat = cv2.getRotationMatrix2D(center, angle, 1.0)
    rot_mat[0, 2] += tx
    rot_mat[1, 2] += ty
    # compose a small shear
    shear_mat = np.array([[1, shear, 0], [0, 1, 0]], dtype=np.float32)

    out = cv2.warpAffine(img, rot_mat, (w, h), borderMode=cv2.BORDER_CONSTANT, borderValue=0.0)
    out = cv2.warpAffine(out, shear_mat, (w, h), borderMode=cv2.BORDER_CONSTANT, borderValue=0.0)

    if RNG.random() < 0.5:
        out = np.fliplr(out)
    if RNG.random() < 0.5:
        out = np.flipud(out)
    return out.astype(np.float32)


def build_splits(labeled_df):
    train_imgs, train_lbls = [], []
    val_imgs, val_lbls = [], []
    test_imgs, test_lbls = [], []

    rng = np.random.default_rng(42)

    for cls in CLASSES:
        sub = labeled_df[labeled_df["label"] == cls]
        idx = sub.index.to_numpy()
        rng.shuffle(idx)

        if cls == "none" and len(idx) > NONE_CAP:
            idx = idx[:NONE_CAP]

        n = len(idx)
        n_test = int(round(n * TEST_FRAC))
        n_val = int(round(n * VAL_FRAC))
        n_train_real = n - n_test - n_val

        test_idx = idx[:n_test]
        val_idx = idx[n_test:n_test + n_val]
        train_idx = idx[n_test + n_val:]

        print(f"[{cls:10s}] real={n:6d}  train_real={len(train_idx):6d}  "
              f"val={len(val_idx):5d}  test={len(test_idx):5d}")

        # --- resize everything once ---
        def to_imgs(index_array):
            return [resize_map(labeled_df.at[i, "waferMap"]) for i in index_array]

        train_real_imgs = to_imgs(train_idx)
        val_imgs_c = to_imgs(val_idx)
        test_imgs_c = to_imgs(test_idx)

        val_imgs.extend(val_imgs_c)
        val_lbls.extend([CLASS_TO_IDX[cls]] * len(val_imgs_c))
        test_imgs.extend(test_imgs_c)
        test_lbls.extend([CLASS_TO_IDX[cls]] * len(test_imgs_c))

        # --- rebalance TRAIN split only ---
        target = TRAIN_TARGET_PER_CLASS
        if len(train_real_imgs) >= target:
            chosen = rng.choice(len(train_real_imgs), size=target, replace=False)
            final_train = [train_real_imgs[i] for i in chosen]
        else:
            final_train = list(train_real_imgs)
            deficit = target - len(final_train)
            # sample (with replacement) real images to augment
            source_pool = train_real_imgs if len(train_real_imgs) > 0 else val_imgs_c
            for _ in range(deficit):
                base = source_pool[rng.integers(0, len(source_pool))]
                final_train.append(augment_one(base))

        train_imgs.extend(final_train)
        train_lbls.extend([CLASS_TO_IDX[cls]] * len(final_train))

    def pack(imgs, lbls):
        X = np.stack(imgs).astype(np.float32)[:, None, :, :]  # (N,1,H,W)
        y = np.array(lbls, dtype=np.int64)
        return X, y

    Xtr, ytr = pack(train_imgs, train_lbls)
    Xval, yval = pack(val_imgs, val_lbls)
    Xte, yte = pack(test_imgs, test_lbls)

    # shuffle train set (classes were appended block-wise)
    perm = rng.permutation(len(ytr))
    Xtr, ytr = Xtr[perm], ytr[perm]

    return (Xtr, ytr), (Xval, yval), (Xte, yte)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    labeled = load_labeled_dataframe()
    (Xtr, ytr), (Xval, yval), (Xte, yte) = build_splits(labeled)

    print("\nFinal shapes:")
    print("  train:", Xtr.shape, ytr.shape)
    print("  val:  ", Xval.shape, yval.shape)
    print("  test: ", Xte.shape, yte.shape)

    np.savez_compressed(os.path.join(OUT_DIR, "train.npz"), X=Xtr, y=ytr)
    np.savez_compressed(os.path.join(OUT_DIR, "val.npz"), X=Xval, y=yval)
    np.savez_compressed(os.path.join(OUT_DIR, "test.npz"), X=Xte, y=yte)
    with open(os.path.join(OUT_DIR, "classes.txt"), "w") as f:
        f.write("\n".join(CLASSES))
    print("\nSaved to", OUT_DIR)


if __name__ == "__main__":
    main()
