"""
Bayesian hyperparameter optimization (Optuna, TPE sampler) over the
classifier's learning rate, dropout rate, base filter width, and weight
decay. Each trial trains a quick proxy (few epochs) and reports the best
validation accuracy reached. The final chosen configuration is re-trained
for many more epochs in final_train.py.
"""
import json
import sys
import optuna
import torch

sys.path.insert(0, "/home/deep/Wafetr_defect/project/src")
from train_classifier import train_one_config
from common import get_device, configure_cpu_threads

N_TRIALS = 15
PROXY_EPOCHS = 6
RESULTS_PATH = "/home/deep/Wafetr_defect/project/data/hpo_results.json"
# v2: fresh study/db -- the search space was narrowed after trial 0 (to fix
# a transient OOM caused by a GPU-memory leak, since fixed; see report), and
# Optuna's persistent storage rejects a narrowed categorical distribution
# against the same study name.
STUDY_DB = "sqlite:////home/deep/Wafetr_defect/project/data/optuna_study_v2.db"


def objective(trial):
    # Kept to a safe memory envelope: this shared GPU typically has only
    # ~2 GiB headroom when other users' jobs are active, and base_filters=48
    # with batch_size=128 was observed to exceed that and stall for 20+
    # minutes (see report, Sec. "Compute constraints").
    base_filters = trial.suggest_categorical("base_filters", [16, 32])
    dropout = trial.suggest_float("dropout", 0.1, 0.5)
    lr = trial.suggest_float("lr", 1e-4, 5e-3, log=True)
    weight_decay = trial.suggest_float("weight_decay", 1e-6, 1e-3, log=True)
    batch_size = trial.suggest_categorical("batch_size", [32, 64])

    print(f"\n[Trial {trial.number}] base_filters={base_filters} dropout={dropout:.3f} "
          f"lr={lr:.5f} weight_decay={weight_decay:.6f} batch_size={batch_size}", flush=True)

    result = train_one_config(base_filters=base_filters, dropout=dropout, lr=lr,
                               weight_decay=weight_decay, batch_size=batch_size,
                               epochs=PROXY_EPOCHS, use_pretrained_encoder=True,
                               verbose=True)
    trial.set_user_attr("val_prec_macro", result["best_val_prec"])
    return result["best_val_acc"]


def main():
    configure_cpu_threads()
    print("Device:", get_device(), flush=True)
    sampler = optuna.samplers.TPESampler(seed=42)
    study = optuna.create_study(direction="maximize", sampler=sampler,
                                 storage=STUDY_DB, study_name="wafer_cnn_hpo",
                                 load_if_exists=True)
    study.optimize(objective, n_trials=N_TRIALS)

    print("\n=== HPO complete ===", flush=True)
    print("Best value (val acc):", study.best_value, flush=True)
    print("Best params:", study.best_params, flush=True)

    out = {
        "best_value": study.best_value,
        "best_params": study.best_params,
        "best_val_prec_macro": study.best_trial.user_attrs.get("val_prec_macro"),
        "all_trials": [
            {"number": t.number, "value": t.value, "params": t.params,
             "val_prec_macro": t.user_attrs.get("val_prec_macro")}
            for t in study.trials
        ],
    }
    with open(RESULTS_PATH, "w") as f:
        json.dump(out, f, indent=2)
    print("Saved HPO results to", RESULTS_PATH, flush=True)


if __name__ == "__main__":
    main()
