#!/bin/bash
# Resume the pipeline from stage 2 onward (autoencoder pretraining already
# completed and checkpointed). Waits for free GPU memory, same as
# wait_and_train.sh, then runs HPO -> final training -> evaluation -> plots.
set -uo pipefail

PY=/home/deep/miniconda3/envs/magnetic_ai/bin/python3
SRC=/home/deep/Wafetr_defect/project/src
LOG=/home/deep/Wafetr_defect/project/results/pipeline.log
THRESHOLD_MIB=1000
REQUIRED_CONSECUTIVE=2
POLL_SECONDS=15
MAX_WAIT_HOURS=48

echo "" | tee -a "$LOG"
echo "[$(date)] RESUMING from stage 2 (autoencoder already complete)." | tee -a "$LOG"
echo "[$(date)] Waiting for >= ${THRESHOLD_MIB} MiB free on GPU 0..." | tee -a "$LOG"

consecutive=0
elapsed=0
max_elapsed=$((MAX_WAIT_HOURS * 3600))

while [ "$elapsed" -lt "$max_elapsed" ]; do
    free_mib=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits -i 0 2>/dev/null | head -1)
    if [ -z "$free_mib" ]; then
        consecutive=0
    elif [ "$free_mib" -ge "$THRESHOLD_MIB" ]; then
        consecutive=$((consecutive + 1))
        echo "[$(date)] free=${free_mib} MiB -- ${consecutive}/${REQUIRED_CONSECUTIVE} consecutive checks" | tee -a "$LOG"
        if [ "$consecutive" -ge "$REQUIRED_CONSECUTIVE" ]; then
            echo "[$(date)] GPU confirmed free. Resuming pipeline." | tee -a "$LOG"
            break
        fi
    else
        consecutive=0
    fi
    sleep "$POLL_SECONDS"
    elapsed=$((elapsed + POLL_SECONDS))
done

run_stage () {
    name="$1"; shift
    echo "" | tee -a "$LOG"
    echo "=================================================================" | tee -a "$LOG"
    echo "[$(date)] STAGE: $name" | tee -a "$LOG"
    echo "=================================================================" | tee -a "$LOG"
    "$@" 2>&1 | tee -a "$LOG"
    rc=${PIPESTATUS[0]}
    if [ "$rc" -ne 0 ]; then
        echo "[$(date)] STAGE FAILED: $name (exit $rc)" | tee -a "$LOG"
        exit "$rc"
    fi
}

run_stage "2. Bayesian hyperparameter search (resumed)" "$PY" "$SRC/hpo.py"
run_stage "3. Final classifier training"                "$PY" "$SRC/final_train.py"
run_stage "4. Held-out test-set evaluation"              "$PY" "$SRC/evaluate.py"
run_stage "5. Generating report figures"                 "$PY" "$SRC/make_plots.py"

echo "" | tee -a "$LOG"
echo "[$(date)] PIPELINE COMPLETE. See $LOG and project/results/metrics.json" | tee -a "$LOG"
