"""
Classifier training: reuses the pretrained autoencoder encoder as the
feature-extraction backbone, adds the Spatial-2D-Dropout + dense
classification head, and fine-tunes end-to-end on the balanced 60K
training set. Used both as a quick proxy objective by the Bayesian
(Optuna/TPE) hyperparameter search and, with more epochs, for the final
model.
"""
import time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import accuracy_score, precision_score

import sys
sys.path.insert(0, "/home/deep/Wafetr_defect/project/src")
from model import Encoder, WaferCNNClassifier
from common import get_device, run_step_with_oom_retry, configure_cpu_threads

DATA_DIR = "/home/deep/Wafetr_defect/project/data"
AE_CKPT = "/home/deep/Wafetr_defect/project/data/autoencoder.pt"
DEVICE = get_device()


def load_data():
    tr = np.load(f"{DATA_DIR}/train.npz")
    va = np.load(f"{DATA_DIR}/val.npz")
    te = np.load(f"{DATA_DIR}/test.npz")
    return (tr["X"], tr["y"]), (va["X"], va["y"]), (te["X"], te["y"])


def make_loader(X, y, batch_size, shuffle):
    ds = TensorDataset(torch.from_numpy(X), torch.from_numpy(y))
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle,
                       num_workers=2, pin_memory=(DEVICE == "cuda"))


@torch.no_grad()
def evaluate_loader(model, loader):
    model.eval()
    preds, labels = [], []
    for xb, yb in loader:
        xb = xb.to(DEVICE)
        out = model(xb)
        preds.append(out.argmax(1).cpu().numpy())
        labels.append(yb.numpy())
    preds = np.concatenate(preds)
    labels = np.concatenate(labels)
    acc = accuracy_score(labels, preds)
    prec = precision_score(labels, preds, average="macro", zero_division=0)
    return acc, prec, preds, labels


def train_one_config(base_filters=32, dropout=0.3, lr=1e-3, weight_decay=1e-4,
                      batch_size=128, epochs=20, use_pretrained_encoder=True,
                      freeze_encoder_epochs=0, verbose=True):
    """Train one classifier configuration. Returns best val accuracy,
    best val precision (macro), and the state dict of the best model."""
    (Xtr, ytr), (Xval, yval), (Xte, yte) = load_data()
    train_loader = make_loader(Xtr, ytr, batch_size, shuffle=True)
    val_loader = make_loader(Xval, yval, batch_size, shuffle=False)

    encoder = Encoder(base_filters=base_filters)
    if use_pretrained_encoder:
        try:
            ckpt = torch.load(AE_CKPT, map_location="cpu", weights_only=False)
            if ckpt.get("base_filters") == base_filters:
                encoder.load_state_dict(ckpt["encoder_state"])
                if verbose:
                    print("  loaded pretrained encoder weights", flush=True)
        except FileNotFoundError:
            if verbose:
                print("  no autoencoder checkpoint found, training encoder from scratch", flush=True)

    model = WaferCNNClassifier(num_classes=9, base_filters=base_filters,
                                dropout=dropout, encoder=encoder).to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="max", factor=0.5, patience=3)
    crit = nn.CrossEntropyLoss()

    best_acc = -1.0
    best_prec = -1.0
    best_state = None
    history = []

    for epoch in range(1, epochs + 1):
        t0 = time.time()
        if freeze_encoder_epochs and epoch <= freeze_encoder_epochs:
            for p in model.encoder.parameters():
                p.requires_grad = False
        else:
            for p in model.encoder.parameters():
                p.requires_grad = True

        model.train()
        total_loss, n = 0.0, 0
        for xb, yb in train_loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)

            def step():
                opt.zero_grad()
                out = model(xb)
                loss = crit(out, yb)
                loss.backward()
                opt.step()
                return loss.item()

            loss_val = run_step_with_oom_retry(step) if DEVICE == "cuda" else step()
            total_loss += loss_val * xb.size(0)
            n += xb.size(0)

        val_acc, val_prec, _, _ = evaluate_loader(model, val_loader)
        sched.step(val_acc)
        history.append({"epoch": epoch, "train_loss": total_loss / n,
                         "val_acc": val_acc, "val_prec_macro": val_prec})
        if verbose:
            print(f"  epoch {epoch:3d}/{epochs}  train_loss={total_loss/n:.4f}  "
                  f"val_acc={val_acc:.4f}  val_prec_macro={val_prec:.4f}  "
                  f"({time.time()-t0:.1f}s)", flush=True)

        if val_acc > best_acc:
            best_acc = val_acc
            best_prec = val_prec
            # IMPORTANT: copy to CPU. A plain deepcopy of a CUDA state_dict
            # keeps a full duplicate of the model resident on the GPU for as
            # long as the caller holds the result (e.g. every HPO trial),
            # which silently accumulates GPU memory across trials/epochs on
            # this shared box until later trials spuriously OOM.
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    # release this trial's GPU-resident model/optimizer before returning,
    # so the next HPO trial starts from a clean memory slate
    del model, opt, sched
    if DEVICE == "cuda":
        torch.cuda.empty_cache()

    return {"best_val_acc": best_acc, "best_val_prec": best_prec,
            "best_state": best_state, "history": history,
            "config": dict(base_filters=base_filters, dropout=dropout, lr=lr,
                            weight_decay=weight_decay, batch_size=batch_size,
                            epochs=epochs)}


if __name__ == "__main__":
    configure_cpu_threads()
    print("Device:", DEVICE, flush=True)
    result = train_one_config(epochs=30, verbose=True)
    print("Best val acc:", result["best_val_acc"], "Best val prec:", result["best_val_prec"])
    torch.save({"state": result["best_state"], "config": result["config"]},
               "/home/deep/Wafetr_defect/project/data/classifier_default.pt")
